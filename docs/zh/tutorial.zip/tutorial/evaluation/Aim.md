## 自定义评估

### 1、什么是Aim

&emsp;&emsp;一个易于使用且功能强大的开源实验跟踪器，Aim能记录您的运行，使漂亮的UI来比较它们。并且可以与您喜欢的工具无缝集成。

<div align="center">
  <sub>Integrates seamlessly with your favorite tools</sub>
  <br/>
  <br/>
  <img src="https://user-images.githubusercontent.com/13848158/155354389-d0301620-77ea-4629-a743-f7aa249e14b5.png" width="60" /><img src="https://user-images.githubusercontent.com/13848158/155354496-b39d7b1c-63ef-40f0-9e59-c08d2c5e337c.png" width="60" /><img src="https://user-images.githubusercontent.com/13848158/155354380-3755c741-6960-42ca-b93e-84a8791f088c.png" width="60" /><img src="https://user-images.githubusercontent.com/13848158/155354342-7df0ef5e-63d2-4df7-b9f1-d2fc0e95f53f.png" width="60" /><img src="https://user-images.githubusercontent.com/13848158/155354392-afbff3de-c845-4d86-855d-53df569f91d1.png" width="60" />
  <img src="https://user-images.githubusercontent.com/13848158/155354355-89210506-e7e5-4d37-b2d6-ad3fda62ef13.png" width="60" />
  <img src="https://user-images.githubusercontent.com/13848158/155354397-8af8e1d3-4067-405e-9d42-1f131663ed22.png" width="60" />
  <br/>
  <img src="https://user-images.githubusercontent.com/13848158/155354513-f7486146-3891-4f3f-934f-e58bbf9ce695.png" width="60" />
  <img src="https://user-images.githubusercontent.com/13848158/155354500-c0471ce6-b2ce-4172-b9e4-07a197256303.png" width="60" />
  <img src="https://user-images.githubusercontent.com/13848158/155354361-9f911785-008d-4b75-877e-651e026cf47e.png" width="60" />
  <img src="https://user-images.githubusercontent.com/13848158/155354373-1879ae61-b5d1-41f0-a4f1-04b639b6f05e.png" width="60" />
  <img src="https://user-images.githubusercontent.com/13848158/155354483-75d9853f-7154-4d95-8190-9ad7a73d6654.png" width="60" />
  <img src="https://user-images.githubusercontent.com/13848158/155354329-cf7c3352-a72a-478d-82a7-04e3833b03b7.png" width="60" />
  <img src="https://user-images.githubusercontent.com/13848158/155354349-dcdf3bc3-d7a9-4f34-8258-4824a57f59c7.png" width="60" />
  <img src="https://user-images.githubusercontent.com/13848158/155354471-518f1814-7a41-4b23-9caf-e516507343f1.png" width="60" />
  <img src="https://user-images.githubusercontent.com/48801049/165162736-2cc5da39-38aa-4093-874f-e56d0ba9cea2.png" width="60" />
  <img src="https://user-images.githubusercontent.com/48801049/165074282-36ad18eb-1124-434d-8439-728c22cd7ac7.png" width="60" />
</div>

<div align="center">
  <br/>
  <kbd>
    <img width="650px" src="https://user-images.githubusercontent.com/13848158/136374529-af267918-5dc6-4a4e-8ed2-f6333a332f96.gif" />
  </kbd>
</div>

### 2、Aim与MindSpore结合：

&emsp;&emsp;导入相应的库函数：

```Python
import argparse
import mindspore.nn as nn

#对应的数据和网络
from mindvision.classification.dataset import Mnist
from mindvision.classification.models import lenet

from mindspore import load_checkpoint, load_param_into_net
from mindspore.train import Model
from mindspore.train.callback import ModelCheckpoint, CheckpointConfig
from mindspore.train.callback import Callback, LossMonitor
#Aim
from aim import Run
#import moxing as mox
```

&emsp;&emsp;定义parse_args模块：--pretrain_url:表示定义pretrain_url这个参数，type表示参数的类型，default表示参数的路径，./lenet/lenet-1_1875.ckpt'表示参数存放的路径，help介绍参数作用

```Python
def parse_args():
    # 创建解析
    parser = argparse.ArgumentParser(description="train mnist",
                                     formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    # 添加参数
    parser.add_argument('--pretrain_url', type=str, default='./lenet/lenet-1_1875.ckpt', help='the training data')
    parser.add_argument('--data_url', type=str, default='./mnist', help='the training data')
    parser.add_argument('--output_url', default='./lenet', type=str, help='the path model saved')
    parser.add_argument('--aimrepo_url', default='./db', type=str, help='the aim database repo path')
    # 解析参数
    args_opt = parser.parse_args()
    return args_opt
```

&emsp;&emsp;自定义Callback：

```python
    #追踪Aim的loss、训练集accuracy、测试集accuracy
  	self.aim_run.track(float(str(loss)), name='loss', epoch=epoch_num, context={"subset": "train"})
    self.aim_run.track(float(str(train_acc['accuracy'])), name='accuracy', epoch=epoch_num, context={"subset": "train"})
    self.aim_run.track(float(str(test_acc['accuracy'])), name='accuracy', epoch=epoch_num, context={"subset": "test"})
```

```python
# 自定义Callback
class AimCallback(Callback):
    def __init__(self, model, dataset_test, aim_run):
        super(AimCallback, self).__init__()
        self.aim_run = aim_run  # 传入aim实例
        self.model = model  # 传入model，用于eval
        self.dataset_test = dataset_test  # 传入dataset_test, 用于eval test

    def step_end(self, run_context):
        """step end"""
        cb_params = run_context.original_args()
        # loss
        epoch_num = cb_params.cur_epoch_num
        step_num = cb_params.cur_step_num
        loss = cb_params.net_outputs
        run1 = self.aim_run.track(float(str(loss)), name='loss', step=step_num, epoch=epoch_num,context={"subset": "train"})
#定义
    def epoch_end(self, run_context):
        """epoch end"""
        cb_params = run_context.original_args()
        # loss
        epoch_num = cb_params.cur_epoch_num
        step_num = cb_params.cur_step_num
        loss = cb_params.net_outputs
        train_dataset = cb_params.train_dataset
        train_acc = self.model.eval(train_dataset)
        test_acc = self.model.eval(self.dataset_test)
        print("【Epoch:】", epoch_num, "【Step:】", step_num, "【loss:】", loss, "【train_acc:】", train_acc['accuracy'], "【test_acc:】",test_acc['accuracy'])
#Aim追踪损失
        self.aim_run.track(float(str(loss)), name='loss', epoch=epoch_num, context={"subset": "train"})
#Aim追踪训练集的准确率
        self.aim_run.track(float(str(train_acc['accuracy'])), name='accuracy', epoch=epoch_num, context={"subset": "train"})
#Aim追踪测试集的准确率
        self.aim_run.track(float(str(test_acc['accuracy'])), name='accuracy', epoch=epoch_num, context={"subset": "test"})
```

&emsp;&emsp;定义训练模块：在MindSpore训练代码中添加Aim

```python
 #Aim  	          
				 aim_run = Run(repo=args_opt.aimrepo_url, #           
                      experiment=f{args_opt.output_url}/ # 
                      bs{batch_size}_lr{learning_rate}_mt{momentum}") 
         # Aim对应的参数
         aim_run['learning_rate'] = learning_rate
         aim_run['momentum'] = momentum
         aim_run['batch_size'] = batch_size
```

## 3.自动评估

- 评估方式1——训练日志可视化

  根据代码顺序输入Grid Search的超参数范围，注意为浮点数列表，为空时输入`[]`

```python
def train(args_opt):
    # 超参数范围的输入
    batch_size_choice = [32, 64, 128]
    learning_rate_choice = [0.01, 0.001, 0.0001]
    momentum_choice = [0.9, 0.99]

    for batch_size in batch_size_choice:
        for learning_rate in learning_rate_choice:
            for momentum in momentum_choice:
                # 将模型参数存入parameter的字典中，这里加载的是上面训练过程中保存的模型参数
                param_dict = load_checkpoint(args_opt.pretrain_url)
                # 重新定义一个LeNet神经网络
                network = lenet(num_classes=10, pretrained=False)
                # 将参数加载到网络中
                load_param_into_net(network, param_dict)

                # 定义损失函数
                net_loss = nn.SoftmaxCrossEntropyWithLogits(sparse=True, reduction='mean')
                # 定义优化器函数
                net_opt = nn.Momentum(network.trainable_params(), learning_rate=learning_rate, momentum=momentum)
                model = Model(network, loss_fn=net_loss, optimizer=net_opt, metrics={"accuracy"})

                # 定义训练数据集
                download_train = Mnist(path=args_opt.data_url, split="train", batch_size=batch_size, repeat_num=1, shuffle=True, resize=32,
                                       download=True)
                # 定义测试数据集
                download_eval = Mnist(path=args_opt.data_url, split="test", batch_size=batch_size, repeat_num=1, shuffle=True, resize=32,
                                      download=True)
                dataset_train = download_train.run()
                dataset_test = download_eval.run()

                # 设置模型保存参数
                config_ck = CheckpointConfig(save_checkpoint_steps=int(60000/batch_size), keep_checkpoint_max=20)

                # 应用模型保存参数
                ckpoint = ModelCheckpoint(prefix="lenet", directory=args_opt.output_url, config=config_ck)
                # Aim
                aim_run = Run(repo=args_opt.aimrepo_url, experiment=f"{args_opt.output_url}/bs{batch_size}_lr{learning_rate}_mt{momentum}")

                # Log run parameters
                aim_run['learning_rate'] = learning_rate
                aim_run['momentum'] = momentum
                aim_run['batch_size'] = batch_size
                
                # 训练网络模型
                model.train(2, dataset_train, callbacks=[ckpoint, AimCallback(model, dataset_test, aim_run)])
```

评估方式2——自定义评估

点击 `自定义评估` 页签，若您满足自定义评估的必要条件，将会出现如下界面。

![自定义评估](https://obs-xihe-beijing4.obs.cn-north-4.myhuaweicloud.com/xihe-img/projects/quick_start/lenet/quickstart_customize.png)

> 注：在训练完成之后，才可进行评估功能，自定义评估的必要条件参考 [自定义评估](https://xihe-docs.mindspore.cn/zh/tutorial/Lenet5/)

3.1点击`开始评估`按钮

点击开始评估，按钮会转到评估中状态，此时按钮是不可用，且自定义评估方式等待时间会较长，请您耐心等待。

3.2查看报告

- 评估方式1——训练日志可视化

  点击查看报告，进入如下页面，您也可以在左侧导航栏右键打开一个新页面

  ![训练日志可视化](https://obs-xihe-beijing4.obs.cn-north-4.myhuaweicloud.com/xihe-img/projects/quick_start/lenet/quickstart_aim.png)

  点击左侧导航栏Runs，可以查看对比组列表。

  ![aim-Runs](https://obs-xihe-beijing4.obs.cn-north-4.myhuaweicloud.com/xihe-img/projects/quick_start/lenet/quickstart_aim_runs.png)

  点击某一个Runs，可以查看一种实验下的走势图。

  比如点击第一个Run，learning_rate为0.0001，momentum为0.99，batch_size 为128。

  选择`Metrics`页签，可以查看此超参数下不同监测指标的走势图。

  ![image-20220716204725462](https://obs-xihe-beijing4.obs.cn-north-4.myhuaweicloud.com/xihe-img/projects/quick_start/lenet/quickstart_aim_metrics.png)

  点击左侧导航栏Metrics，可以查看所有metrcis的走势图汇总

  ![aim-Metrics](https://obs-xihe-beijing4.obs.cn-north-4.myhuaweicloud.com/xihe-img/projects/quick_start/lenet/quickstart_aim_metricslist.png)

  点击左侧导航栏Params，可以查看对比图，可以直接看出哪个超参数下有最好的metrics。

  比如下图我们使用控制变量法，查看在batch_size为64，momentum为0.9时，哪个leanring_rate为那个loss最小。由下图可知，learning_rate为0.1时最小。

  ![aim-Parms](https://obs-xihe-beijing4.obs.cn-north-4.myhuaweicloud.com/xihe-img/projects/quick_start/lenet/quickstart_aim_params.png)

  > 注：若您想要获取更多监控指标，建议您自定义Aim代码，选择自定义评估的方式，详情参考 [自定义评估](https://xihe-docs.mindspore.cn/zh/tutorial/Lenet5/)

- 评估方式2——自定义评估

  此案例增加了一个测试数据集的acc，效果图如下：

  ![自定义评估](https://obs-xihe-beijing4.obs.cn-north-4.myhuaweicloud.com/xihe-img/projects/quick_start/lenet/quickstart_aim_customize.png)

  分析loss走势图，随着epoch的增加，loss反而往上，且在2.4左右反复震荡，可以猜测，loss陷入到了一个局部最优点，需要设置一个更大的learning_rate冲出局部最优点。

  由此得出一个简单的结论，可以设置一个更大的learning_rate、momentum或者选择自适应优化器等。

  若您要体验和评估方式1一样的对比效果的话，您需要更改如下:

  

  ```python
  def train(args_opt):
      # ablation experiments
      batch_size_choice = [32, 64, 128]
      learning_rate_choice = [0.01, 0.001, 0.0001]
      momentum_choice = [0.9, 0.99]
  
      for batch_size in batch_size_choice:
          for learning_rate in learning_rate_choice:
              for momentum in momentum_choice:
                  # 将模型参数存入parameter的字典中，这里加载的是上面训练过程中保存的模型参数
                  param_dict = load_checkpoint(args_opt.pretrain_url)
                  # 重新定义一个LeNet神经网络
                  network = lenet(num_classes=10, pretrained=False)
                  # 将参数加载到网络中
                  load_param_into_net(network, param_dict)
                  ...
  ```

  您需要注意的是此种方式生成报告的时间会很长，请耐心等待。
